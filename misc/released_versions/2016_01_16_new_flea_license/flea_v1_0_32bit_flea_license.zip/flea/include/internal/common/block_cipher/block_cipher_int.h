/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _flea_block_cipher_int__H_
#define _flea_block_cipher_int__H_

#include "flea/error.h"
#include "flea/block_cipher_fwd.h"

#define FLEA_BLOCK_CIPHER_MAX_EXPANDED_KEY_U32_SIZE __FLEA_COMPUTED_BLOCK_CIPHER_MAX_EXPANDED_KEY_U32_SIZE

typedef void (*flea_cipher_block_processing_f)(const flea_ecb_mode_ctx_t* p_ctx, const flea_u8_t* input, flea_u8_t* output);

typedef flea_err_t (*THR_flea_block_cipher_key_sched_f)(flea_ecb_mode_ctx_t* ctx, const flea_u8_t* cipherKey);

struct struct_flea_block_cipher_config_entry_t;
typedef struct struct_flea_block_cipher_config_entry_t flea_block_cipher_config_entry_t;

typedef enum { des, aes } flea_block_cipher_raw_id_t;

struct struct_flea_block_cipher_config_entry_t
{
  flea_block_cipher_id_t ext_id__t;
  flea_block_cipher_raw_id_t raw_id__t;
  flea_u16_t key_bit_size;
  flea_u16_t expanded_key_u32_size__al_u16;

  flea_cipher_block_processing_f cipher_block_encr_function;
  flea_cipher_block_processing_f cipher_block_decr_function;

  THR_flea_block_cipher_key_sched_f THR_key_sched_encr_function;
  THR_flea_block_cipher_key_sched_f THR_key_sched_decr_function;

  flea_u8_t block_length__u8;

};


#endif /* h-guard */
