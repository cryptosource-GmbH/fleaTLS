var group__pltf__support =
[
    [ "FLEA_HAVE_STDLIB_FILESYSTEM", "group__pltf__support.html#ga12a8c52b7534c6047627ac95a5ac0984", null ]
];