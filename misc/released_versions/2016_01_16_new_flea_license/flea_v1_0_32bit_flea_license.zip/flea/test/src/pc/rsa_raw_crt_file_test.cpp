/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "flea/types.h"
#include "self_test.h"
#include <string>
#include <vector>
#include <cstring>
#include <fstream>
#include <iostream>
#include "pc/test_util.h"

#ifdef FLEA_HAVE_RSA 

#define CHECK_NOT_NEGATIVE(__f) do { if(__f < 0) { return FLEA_ERR_INT_ERR; } }while(0)
#define CHECK_ZERO(__f) do { if(__f != 0) { return FLEA_ERR_INT_ERR; } }while(0)
static flea_err_t THR_flea_test_crt_rsa_raw_file_based_for_file(std::string const& leaf_name)
{
  std::string file_name = "misc/testdata/" + leaf_name; //.dat";
  unsigned mod_byte_len = 2048/8;
  std::ifstream input(file_name.c_str()); 
  std::string line;
  bool end = false;
  try
  {
    while(!end)
    {
      std::vector<flea_u8_t> p = parse_line("p", 0,  input);
      std::vector<flea_u8_t> q = parse_line("q", 0, input);
      std::vector<flea_u8_t> d1 = parse_line("d1",  0, input);
      std::vector<flea_u8_t> d2 = parse_line("d2",  0, input);
      std::vector<flea_u8_t> q_inv = parse_line("q_inv",  0, input);
      std::vector<flea_u8_t> pub_exp = parse_line("pub_exp", mod_byte_len, input);
      std::vector<flea_u8_t> priv_exp = parse_line("priv_exp", mod_byte_len, input);
      std::vector<flea_u8_t> mod = parse_line("mod", mod_byte_len, input);
      std::vector<flea_u8_t> message = parse_line("message", mod_byte_len, input);
      std::vector<flea_u8_t> ciphertext = parse_line("signature", mod_byte_len, input);
      std::string line;
      if(!getline(input, line))
      {
        std::cout << "file error" << std::endl;
        return FLEA_ERR_INT_ERR;
      }
      if(line.find(std::string("next")) == 0)
      {
        //std::cout << "next test: " << line << std::endl;
        // nothing to do
      }
      else if(line.find(std::string("end")) == 0)
      {
        end = true;
      }

      if(0 != THR_flea_test_rsa_crt_inner(
            mod_byte_len,
            &ciphertext[0],
            &message[0],
            &p[0], 
            p.size(),
            &q[0],
            q.size(),
            &d1[0],
            d1.size(),
            &d2[0],
            d2.size(),
            &q_inv[0],
            q_inv.size(),
            //&pub_exp[0],
            &mod[0]))
      {
        std::cout << "error in file " << leaf_name << ", test with mod = ";
        for(unsigned j = 0; j < mod.size(); j++)
        {
          std::printf("%02x", mod[j]);
        }
        std::cout << std::endl;
        return FLEA_ERR_FAILED_TEST;
      } 
    } // end while loop
  }
  catch(std::exception & e)
  {
    std::cout << "error during the parsing of test data" << e.what() << std::endl;
    throw(e);
  }
  return FLEA_ERR_FINE;
}


flea_err_t THR_flea_test_crt_rsa_raw_file_based()
{
CHECK_ZERO(THR_flea_test_crt_rsa_raw_file_based_for_file(std::string("raw_crt_rsa_2048_previous_failure.dat")));
CHECK_ZERO(THR_flea_test_crt_rsa_raw_file_based_for_file(std::string("raw_crt_rsa_2048_pq_max_32_bit_diff.dat")));
CHECK_ZERO(THR_flea_test_crt_rsa_raw_file_based_for_file(std::string("raw_crt_rsa_2048_with_short_messages.dat"))); // also features d1,d2,q_inv one byte shorter than mod
// rather redundant now:
//CHECK_ZERO(THR_flea_test_crt_rsa_raw_file_based_for_file(std::string("raw_crt_rsa_2048.dat")));
return FLEA_ERR_FINE;
}

#endif
