/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "self_test.h"
#include "stdio.h"
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <sys/time.h> // Linux specific

int main (int argc, const char** argv)
{
  flea_u32_t rnd = 0;

  if(argc >= 2)
  {
    if( !strcmp(argv[1], "random"))
    {
      struct timeval tv;
      gettimeofday(&tv, NULL);
      rnd = (tv.tv_sec * tv.tv_usec) ^ tv.tv_sec ^ tv.tv_usec;
      printf("rnd = %u\n", rnd);
    }
    else
    {
      printf("argument 1 must be 'random' or left out\n");
      exit(1);
    }
  }
  return flea_unit_tests(rnd);
}
