/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/



#ifndef _flea_pk_api_int__H_
#define _flea_pk_api_int__H_


flea_err_t THR_flea_pk_api__encode_message__emsa1(flea_u8_t* input_output, flea_al_u16_t input_len, flea_al_u16_t* output_len, flea_al_u16_t bit_size);

flea_err_t THR_flea_pk_api__verify_message__pkcs1_v1_5(const flea_u8_t* encoded, flea_al_u16_t encoded_len, const flea_u8_t* digest, flea_al_u16_t digest_len, flea_al_u16_t bit_size, flea_hash_id_t hash_id);

flea_err_t THR_flea_pk_api__encode_message__pkcs1_v1_5_encr(flea_u8_t* input_output__pu8, flea_al_u16_t input_len__alu16, flea_al_u16_t* output_len__palu16, flea_al_u16_t bit_size, flea_hash_id_t hash_id__t);

flea_err_t THR_flea_pk_api__encode_message__pkcs1_v1_5_sign(flea_u8_t* input_output__pu8, flea_al_u16_t input_len__alu16, flea_al_u16_t* output_len__palu16, flea_al_u16_t bit_size, flea_hash_id_t hash_id__t);

flea_err_t THR_flea_pk_api__decode_message__pkcs1_v1_5(const flea_u8_t* encoded__pcu8, flea_al_u16_t encoded_len__alu16, flea_u8_t* output_message__pu8, flea_al_u16_t* output_message_len__palu16, flea_al_u16_t bit_size__alu16);

#endif /* h-guard */
