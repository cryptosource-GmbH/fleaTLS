var structflea__gmt__time__t =
[
    [ "day", "structflea__gmt__time__t.html#a008f2caf20edb226c00cf41fba2c552c", null ],
    [ "hours", "structflea__gmt__time__t.html#a539dfd48c389d0d1345e8960e85279b9", null ],
    [ "minutes", "structflea__gmt__time__t.html#a1ac11508e5d2a27b4aa311989af28a26", null ],
    [ "month", "structflea__gmt__time__t.html#a300e33a7cf2519d4a06d1363e903ad37", null ],
    [ "seconds", "structflea__gmt__time__t.html#ab5c68338f510f02eb788b67c5c964279", null ],
    [ "year", "structflea__gmt__time__t.html#a5c9549a7bbfece6b86bc7d02eff019cf", null ]
];