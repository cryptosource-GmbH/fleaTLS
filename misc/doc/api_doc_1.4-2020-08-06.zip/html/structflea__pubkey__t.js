var structflea__pubkey__t =
[
    [ "key_bit_size__u16", "structflea__pubkey__t.html#ac3304c40e4e359ca4718fd5fe86c42a3", null ],
    [ "key_type__t", "structflea__pubkey__t.html#a1fec3374353ab42569847b6d9a0bb4f4", null ],
    [ "primitive_input_size__u16", "structflea__pubkey__t.html#a07bca7096caa6f2d0fb85c6a77f05a5d", null ],
    [ "pubkey_with_params__u", "structflea__pubkey__t.html#a439d366bea286b2059145dfa1bbe851a", null ]
];