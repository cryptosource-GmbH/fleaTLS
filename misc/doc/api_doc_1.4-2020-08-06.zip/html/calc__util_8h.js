var calc__util_8h =
[
    [ "FLEA_CEIL_BYTE_LEN_FROM_BIT_LEN", "calc__util_8h.html#a9bcb0620f0ac05c3838a2ecd2e912148", null ],
    [ "FLEA_CEIL_U32_LEN_FROM_BIT_LEN", "calc__util_8h.html#ac35f034cdeb156550f89eedf16d0ef89", null ],
    [ "FLEA_CEIL_WORD_LEN_FROM_BIT_LEN", "calc__util_8h.html#a5b500ae635db27907545a863a551bb2c", null ],
    [ "FLEA_CEIL_WORD_LEN_FROM_BYTE_LEN", "calc__util_8h.html#a1427a4c04d53d0915960771ca3d8def2", null ],
    [ "FLEA_MAX", "calc__util_8h.html#a2472035613760f2cce33a8902f4c0ae0", null ],
    [ "FLEA_MAX3", "calc__util_8h.html#a4078c5c570a4206f6113db5f807e220e", null ],
    [ "FLEA_MAX4", "calc__util_8h.html#acea8a4aeb26e7abc814ba7754b8ead95", null ],
    [ "FLEA_MAX5", "calc__util_8h.html#a4692755080ee427513e302b9ac2686e9", null ],
    [ "FLEA_MIN", "calc__util_8h.html#a04d04413b89d3cf6700a60385efea5bc", null ],
    [ "FLEA_MIN3", "calc__util_8h.html#a01963ec9fbebda6078bc0bb670afa08f", null ],
    [ "FLEA_MIN4", "calc__util_8h.html#a100ef8c4c370db13d47b980ab8243897", null ]
];