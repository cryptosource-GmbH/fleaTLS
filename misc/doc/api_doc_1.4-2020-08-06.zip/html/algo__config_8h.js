var algo__config_8h =
[
    [ "FLEA_ASYM_MAX_ENCODED_SIG_LEN", "algo__config_8h.html#a9e425ca8c15b90184a4a52e3aa49a4cd", null ],
    [ "FLEA_ASYM_MAX_PLAIN_SIG_LEN", "algo__config_8h.html#aaecf4afe0932977d866419653c712739", null ],
    [ "FLEA_ECDSA_MAX_ASN1_SIG_LEN", "algo__config_8h.html#a57ae099bac73373f596666ed9f5ac34a", null ],
    [ "FLEA_ECDSA_MAX_CONCAT_SIG_LEN", "algo__config_8h.html#a6be33a7893d96d41c3f8d9c0566f3baa", null ],
    [ "FLEA_MAX_HASH_OUT_LEN", "algo__config_8h.html#a10cebc5cbfb85a2a88d82212c0076632", null ],
    [ "FLEA_PK_MAX_INTERNAL_FORMAT_PUBKEY_LEN", "algo__config_8h.html#ad155c063b0bf482b08d516449275b52f", null ],
    [ "FLEA_PK_MAX_PRIMITIVE_INPUT_LEN", "algo__config_8h.html#a02f1735de186415dac5916b8daa6b303", null ],
    [ "FLEA_PK_MAX_PRIMITIVE_OUTPUT_LEN", "algo__config_8h.html#a1a3958ec1646fac647860edba90c7fa8", null ],
    [ "FLEA_PK_MAX_PRIVKEY_LEN", "algo__config_8h.html#af87f3533a67a0df90e5021d5ac966496", null ],
    [ "FLEA_RSA_CRT_KEY_INTERNAL_FORMAT_MAX_BYTE_SIZE", "algo__config_8h.html#a413f52f2cc1faa759e274b11a1fa51d2", null ]
];