/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "internal/common/default.h"
#include "flea/error_handling.h"
#include "flea/bin_utils.h"
#include "flea/error.h"
#include "flea/alloc.h"

flea_err_t THR_test_enc_BE_bitlen ()
{
  const flea_u8_t e1 []  = { 0x01 };
  const flea_u8_t e1_len = 1;

  const flea_u8_t e2 []  = { 0x80, 0x00 };
  const flea_u8_t e2_len = 16;

  const flea_u8_t e3 []  = { 0x7F, 0x08, 0x01 };
  const flea_u8_t e3_len = 23;

  FLEA_THR_BEG_FUNC();
  if(flea__get_BE_int_bit_len(e1, sizeof(e1)) != e1_len)
  {
    FLEA_THROW("enc BE bit len error 1", FLEA_ERR_FAILED_TEST);
  }
  if(flea__get_BE_int_bit_len(e2, sizeof(e2)) != e2_len)
  {
    FLEA_THROW("enc BE bit len error 2", FLEA_ERR_FAILED_TEST);
  }
  if(flea__get_BE_int_bit_len(e3, sizeof(e3)) != e3_len)
  {
    FLEA_THROW("enc BE bit len error 3", FLEA_ERR_FAILED_TEST);
  }
  FLEA_THR_FIN_SEC_empty();
}

flea_err_t THR_test_incr_enc_BE_int ()
{
  FLEA_DECL_BUF(block__bu8, flea_u8_t, 4);
  flea_u8_t exp_1__acu8[4] = { 0, 0, 0, 1 };
  flea_u8_t exp_2__acu8[4] = { 0, 0, 1, 0 };
  FLEA_THR_BEG_FUNC();
  FLEA_ALLOC_BUF(block__bu8, 4);

  memset(block__bu8, 0, 4);

  flea__increment_encoded_BE_int(block__bu8, 4);

  if(memcmp(block__bu8, exp_1__acu8, sizeof(exp_1__acu8)))
  {
    FLEA_THROW("error in block increment", FLEA_ERR_FAILED_TEST);
  }

  block__bu8[3] = 0xFF;
  flea__increment_encoded_BE_int(block__bu8, 4);

  if(memcmp(block__bu8, exp_2__acu8, sizeof(exp_2__acu8)))
  {
    FLEA_THROW("error in block increment", FLEA_ERR_FAILED_TEST);
  }

  memset(block__bu8, 0xFF, 4);

  flea__increment_encoded_BE_int(block__bu8, 4);
  flea__increment_encoded_BE_int(block__bu8, 4);

  if(memcmp(block__bu8, exp_1__acu8, sizeof(exp_1__acu8)))
  {
    FLEA_THROW("error in block increment", FLEA_ERR_FAILED_TEST);
  }
  FLEA_THR_FIN_SEC(
    FLEA_FREE_BUF_FINAL(block__bu8);
    );

}
