/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#ifndef _flea_oaep__H_
#define _flea_oaep__H_

#include "flea/types.h"
#include "flea/hash.h"


flea_err_t THR_flea_pkcs1_mgf1(flea_u8_t* output__pu8, flea_al_u16_t output_len__alu16, const flea_u8_t* seed__pu8, flea_al_u16_t seed_len__alu16, flea_hash_id_t hash_id__t);

flea_err_t THR_flea_pk_api__encode_message__oaep(flea_u8_t* input_output__pu8, flea_al_u16_t input_len__alu16, flea_al_u16_t* output_len__palu16, flea_al_u16_t bit_size__alu16, flea_hash_id_t hash_id__t);

flea_err_t THR_flea_pk_api__decode_message__oaep(flea_u8_t* result__pu8, flea_al_u16_t* result_len__palu16, flea_u8_t* input__pu8, flea_al_u16_t input_len__alu16, flea_al_u16_t bit_size__alu16, flea_hash_id_t hash_id__t);

#endif /* h-guard */
