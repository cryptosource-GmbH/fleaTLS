/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#include "flea/types.h"

// computes ~crc16
// initial remainder shall be zero for CCIT compatibility
flea_u16_t flea_crc16_ccit_compute (flea_u16_t crc_init__u16, const flea_u8_t* data__pcu8, flea_dtl_t data_len__dtl)
{
  flea_dtl_t i;

  for(i = 0; i < data_len__dtl; i++)
  {
    flea_al_s8_t j;
    flea_u8_t byte = data__pcu8[i];

    crc_init__u16 ^= (byte << 8);
    for(j = 0; j < 8; j++)
    {
      flea_u16_t mask__u16 = -(((crc_init__u16 ) & (1 << 15)) >> 15);
      crc_init__u16 = (crc_init__u16 << 1) ^ (0x1021 & mask__u16);
      byte <<= 1;
    }
  }
  return crc_init__u16;
}
