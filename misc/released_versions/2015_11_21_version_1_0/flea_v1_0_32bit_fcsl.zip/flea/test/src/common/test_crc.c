/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#include "internal/common/default.h"
#include "flea/hash.h"
#include "self_test.h"
#include "flea/error_handling.h"
#include "flea/alloc.h"
#include "flea/crc.h"
#include "flea/algo_config.h"
#include <string.h>

flea_err_t THR_flea_test_crc16 ()
{
  FLEA_THR_BEG_FUNC();
  flea_u16_t crc_init_value__u16 = 0; 
  flea_u16_t exp_res__u16 = 0xC965;   // APPROVED BY 2 ONLINE CALCULATORS
  flea_u16_t crc_res__u16;
  flea_u8_t test_string__au8[] = { 0xAB, 0xCD };
  crc_res__u16 = flea_crc16_ccit_compute(crc_init_value__u16, test_string__au8, sizeof(test_string__au8));

  if(crc_res__u16 != exp_res__u16)
  {
    FLEA_THROW("wrong CRC16 result", FLEA_ERR_FAILED_TEST);
  }
  crc_res__u16 = flea_crc16_ccit_compute(crc_init_value__u16, &test_string__au8[0], 1);
  crc_res__u16 = flea_crc16_ccit_compute(crc_res__u16, &test_string__au8[1], 1);
  if(crc_res__u16 != exp_res__u16)
  {
    FLEA_THROW("wrong CRC16 result", FLEA_ERR_FAILED_TEST);
  }
  FLEA_THR_FIN_SEC_empty();
}
