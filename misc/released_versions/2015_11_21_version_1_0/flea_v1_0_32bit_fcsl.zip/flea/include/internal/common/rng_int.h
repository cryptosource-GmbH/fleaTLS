/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/



#ifndef _flea_rng_int__H_
#define _flea_rng_int__H_

#include "flea/types.h"

/**
 * Function which has to be implemented for each platform. It loads the RNG
 * state from NVM, ensuring that the system will start with a secure RNG state on
 * the each start-up.
 *
 */
flea_err_t THR_flea_user__rng__load_prng_state(flea_u8_t* result__bu8, flea_al_u8_t result_len__alu8);

/**
 * Function which has to be implemented for each platform. It saves a new RNG
 * state in NVM, ensuring that the system will start with a secure RNG state on
 * the next start-up.
 *
 *
 */
flea_err_t THR_flea_user__rng__save_prng_state(const flea_u8_t* state__pcu8, flea_al_u8_t state_len__alu8);

/**
 * This function must be called prior to using any RNG function.
 */
flea_err_t THR_flea_rng__init(void);

/**
 * Function to be called at a point where no future calls to flea RNG functions are
 * conducted.
 */
void flea_rng__deinit(void);
/**
 * Fill a memory area with random bytes using the global RNG. The RNG does not perform flushing to
 * reach forward security. This function is intended to be used in repeated
 * sequence of randomize-calls for optimal performance. At the end of the
 * sequence, flea_rng__flush() shall be called to achieve forward security.
 *
 * @param mem pointer to the memory area to be randomized
 * @param mem_len the length of the area to be randomized
 *
 */
void flea_rng__randomize_no_flush(flea_u8_t* mem, flea_dtl_t mem_len);

/**
 * Cause the global RNG to flush its state in order to achieve forward security.
 * After the flushing operation, it is not possible to recover previous output
 * from the RNG state.
 */
void flea_rng__flush(void);


#endif /* h-guard */
