var structflea__tls__clt__session__t =
[
    [ "for_resumption__u8", "structflea__tls__clt__session__t.html#ad1b84d376634d05664e58ad0606804aa", null ],
    [ "session__t", "structflea__tls__clt__session__t.html#ac1feabf90ace03095694225f8898ea4b", null ],
    [ "session_id__au8", "structflea__tls__clt__session__t.html#acb49c72c34602a8a007f0ddbfb7f3954", null ],
    [ "session_id_len__u8", "structflea__tls__clt__session__t.html#a79766c7744f96e4697f8bc471f140556", null ]
];