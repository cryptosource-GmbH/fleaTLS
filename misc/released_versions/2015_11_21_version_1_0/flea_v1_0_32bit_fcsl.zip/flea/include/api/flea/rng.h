/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/



#ifndef __flea_rng_H_
#define __flea_rng_H_

#include "flea/types.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Function for accessing the static RNG of the flea library.
 */


/**
 * Fill a memory area with random bytes using the global RNG.
 *
 * @param mem pointer to the memory area to be randomized
 * @param mem_len the length of the area to be randomized
 *
 */
void flea_rng__randomize(flea_u8_t* mem, flea_dtl_t mem_len);


/**
 * Reseed the global RNG state in RAM. The persistent NVM state is not affected.
 * Use this function to quickly update the RAM state without a time consuming
 * NVM-write operation.
 *
 * @param seed the seed data to be added
 * @param seed_len the length of seed
 *
 * @return flea error code
 */
flea_err_t  THR_flea_rng__reseed_volatile(const flea_u8_t* seed, flea_dtl_t seed_len);

/**
 * Reseed the global RNG state in RAM. The persistent NVM state is also set to a
 * new value. Use this function to let high entropy seed data take a lasting
 * effect on the RNG's entropy level.
 *
 * @param seed the seed data to be added
 * @param seed_len the length of seed
 *
 * @return flea error code
 */
flea_err_t THR_flea_rng__reseed_persistent(const flea_u8_t* seed, flea_dtl_t seed_len);

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
