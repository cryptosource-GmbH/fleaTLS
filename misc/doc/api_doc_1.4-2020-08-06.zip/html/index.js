var index =
[
    [ "Getting started with fleaTLS on Linux", "gettingStarted.html", [
      [ "Compilation", "gettingStarted.html#compileFlea", null ],
      [ "Running the tests", "gettingStarted.html#runTests", null ],
      [ "Starting TLS server and client", "gettingStarted.html#tlsTestTools", null ]
    ] ],
    [ "The fleaTLS API", "fleaApi.html", [
      [ "Conventions", "fleaApi.html#apiConventions", null ],
      [ "Error Handling", "fleaApi.html#apiErrHandl", null ],
      [ "Object Life-Cycle", "fleaApi.html#apiObjLifeCycle", [
        [ "The Life-Cycle of the Class-Like Types", "fleaApi.html#secClassLikeTypes", null ],
        [ "Properly using fleaTLS Class-Like Types in Application Code", "fleaApi.html#useObjLc", null ],
        [ "Class-Like Types with Non-Throwing ctors", "fleaApi.html#secClassLikeNonThrCtor", null ]
      ] ]
    ] ],
    [ "Using fleaTLS in Development Projects", "devolopWflea.html", [
      [ "Custom Build Systems", "devolopWflea.html#cstmBuildSys", null ],
      [ "Configuration of the library", "devolopWflea.html#devCfg", null ],
      [ "Initializing the library", "devolopWflea.html#devLibInit", [
        [ "RNG seed", "devolopWflea.html#libinitRng", null ],
        [ "Current Time", "devolopWflea.html#libinitNowFunc", null ],
        [ "Concurrency Support", "devolopWflea.html#libinitMutex", null ]
      ] ],
      [ "Custom flea_rw_stream_t Implementation for TLS", "devolopWflea.html#enableTls", [
        [ "Supporting the Read Modes", "devolopWflea.html#tlsRwStream", null ],
        [ "Timeouts and Error Handling", "devolopWflea.html#tlsTimeout", null ],
        [ "Implementation with Unix Sockets", "devolopWflea.html#Example", null ]
      ] ],
      [ "Concurrency Support", "devolopWflea.html#concSupp", null ]
    ] ],
    [ "Restrictions of fleaTLS", "fleaTLSRestrictions.html", null ],
    [ "Random Number Generation", "fleaRng.html", [
      [ "The Global RNG's Life Cycle", "fleaRng.html#secRngLifeCycle", [
        [ "Seed Management", "fleaRng.html#secSeedFile", null ],
        [ "Reseeding the Global RNG with Low Entropy Data", "fleaRng.html#secLowEntropyReseed", null ]
      ] ]
    ] ],
    [ "Hash Functions", "pageHash.html", [
      [ "Hash Functions", "pageHash.html#secHash", [
        [ "Direct Hash Computation", "pageHash.html#secHashConv", null ],
        [ "Iterative Hash Computation", "pageHash.html#secHashIter", null ]
      ] ]
    ] ],
    [ "Block Ciphers", "pageCipher.html", [
      [ "Block Ciphers", "pageCipher.html#secCipher", [
        [ "ECB Mode", "pageCipher.html#secEcbMode", null ],
        [ "CBC Mode", "pageCipher.html#secCbcMode", null ],
        [ "CTR Mode", "pageCipher.html#secCtrMode", null ]
      ] ]
    ] ],
    [ "Message Authentication Codes", "pageMac.html", [
      [ "Message Authentication Codes", "pageMac.html#secMac", [
        [ "Direct MAC Computation", "pageMac.html#secMacDirect", null ],
        [ "Iterative MAC Computation", "pageMac.html#secMacIter", null ]
      ] ]
    ] ],
    [ "Authenticated Encryption in fleaTLS", "pageAe.html", [
      [ "Authenticated Encryption", "pageAe.html#secAe", [
        [ "Direct Authenticated Encryption Computation", "pageAe.html#secAeDirect", null ],
        [ "Iterative Authenticated Encryption Computation", "pageAe.html#secAeIter", null ]
      ] ]
    ] ],
    [ "Public Key Schemes", "pagePubkey.html", [
      [ "Public Key Schemes", "pagePubkey.html#secPubKey", [
        [ "EC Domain Parameters", "pagePubkey.html#secEcDomPar", null ],
        [ "Public and Private Key Instantiation", "pagePubkey.html#secPkKeyInstantion", [
          [ "Decoding of PKCS#8 Encoded Keys", "pagePubkey.html#secPkKeyPkcs8", null ],
          [ "Instantiating a Public Key From an X.509 Certificate", "pagePubkey.html#secPkKeyFromCert", null ]
        ] ],
        [ "Explicit Instantiation", "pagePubkey.html#secPkKeyExpl", null ],
        [ "Encoding of Keys", "pagePubkey.html#secPkKeyEncod", [
          [ "EC Key Generation", "pagePubkey.html#secPkKeyEccGenKey", null ]
        ] ],
        [ "Public-Key Signature Schemes", "pagePubkey.html#secPkSign", [
          [ "Signature Generation", "pagePubkey.html#secPkSignGen", null ],
          [ "Signature Verification", "pagePubkey.html#secPkSignVer", null ]
        ] ],
        [ "Public Key Cryptosystems", "pagePubkey.html#secPkEncrAlgs", [
          [ "Encryption Operation", "pagePubkey.html#secPkEncrAlgsEncr", null ],
          [ "Decryption Operation", "pagePubkey.html#secPkEncrAlgsDecr", null ]
        ] ],
        [ "EC Diffie-Hellman", "pagePubkey.html#secPkEcdh", null ]
      ] ]
    ] ],
    [ "X.509 Certificate Handling", "pageX509.html", [
      [ "X.509 Certificates", "pageX509.html#secX509", [
        [ "Parsing Certificates", "pageX509.html#secX509Parse", null ],
        [ "Validating Certificates", "pageX509.html#secX509Valid", [
          [ "Certification Path Validation", "pageX509.html#secX509TrustStore", null ],
          [ "Mere Checking of Signatures", "pageX509.html#secX509PureSigVer", null ]
        ] ]
      ] ]
    ] ],
    [ "The TLS API", "tlsPage.html", [
      [ "Overview of the TLS Protocol Flow", "tlsPage.html#secTlsFlowOverv", null ],
      [ "Initial Handshake and Application Data Transfer", "tlsPage.html#secInitHsAndAppData", null ],
      [ "Renegotiation", "tlsPage.html#secReneg", null ],
      [ "Session Resumption", "tlsPage.html#secTlsSessRes", [
        [ "TLS Server", "tlsPage.html#secTlsSessResServer", null ],
        [ "TLS Client", "tlsPage.html#secTlsSessResClient", null ]
      ] ],
      [ "Closing the connection", "tlsPage.html#secTlsCloseConn", null ],
      [ "TLS Alert Handling and Sending", "tlsPage.html#secTlsAlerts", null ],
      [ "Cipher Suites", "tlsPage.html#secCipherSuites", null ],
      [ "Requirements for Client and Server Certificates", "tlsPage.html#secTlsReqClServCerts", [
        [ "Certificates", "tlsPage.html#ECDSA", null ]
      ] ],
      [ "TLS Extensions", "tlsPage.html#secTlsExt", [
        [ "Renegotiation Indication Extension", "tlsPage.html#secRenegIndicExt", null ],
        [ "Signature Algorithm Extension", "tlsPage.html#secSigAlgExt", null ],
        [ "Supported Elliptic Curves Extension", "tlsPage.html#secSuppECCurveExt", null ],
        [ "Supported Point Formats Extension", "tlsPage.html#secSuppPointForm", null ],
        [ "Maximum Fragment Length Negotiation Extension", "tlsPage.html#secFragLenExt", [
          [ "TLS Client", "tlsPage.html#secFragLenExtClient", null ],
          [ "TLS Server", "tlsPage.html#secFragLenExtServer", null ],
          [ "Session Resumption", "tlsPage.html#secFragLenExtResumption", null ]
        ] ]
      ] ],
      [ "Concurrency Support", "tlsPage.html#secTlsConc", null ],
      [ "Instantiating TLS Server and Client", "tlsPage.html#secInstTlsClientAndServer", null ],
      [ "Instantiating a TLS Client", "tlsPage.html#secInstTlsClient", null ],
      [ "Instantiating a TLS Server", "tlsPage.html#secInstTlsServer", null ]
    ] ],
    [ "Concurrency", "pageConcurrency.html", [
      [ "Concurrency Support in fleaTLS", "pageConcurrency.html#secConcurrency", [
        [ "Compile-Time Configurations", "pageConcurrency.html#secMutexCompTimeConf", null ],
        [ "Mutex Support", "pageConcurrency.html#Enabling", null ],
        [ "Disabling Mutex Support", "pageConcurrency.html#secDisableMutex", null ],
        [ "Run-Time Configuration", "pageConcurrency.html#secMutexRunTimeConf", null ]
      ] ]
    ] ]
];