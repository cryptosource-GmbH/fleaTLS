/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#ifndef _flea_kdf__H_
#define _flea_kdf__H_

#include "flea/hash.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Peform the ANSI X9.63 key derivation function.
 *
 * @param hash_id id of the hash algorithm to use in the key derivation function
 * @param input pointer to the input data
 * @param input_len length of input
 * @param shared_info shared info value to be used in the key derivation
 * function, may be NULL, then also its length must be 0
 * @param shared_info_len the length of shared_info
 * @param output pointer to the memory area where to store the computation
 * result
 * @param output_len the caller must provide a pointer to a value which contains
 * the available length of output. when the function returns, *output_len will
 * contain the length of the data set in output
 *
 * @return flea error code
 */
flea_err_t THR_flea_kdf_X9_63(flea_hash_id_t id, const flea_u8_t* input, flea_al_u16_t input_len, const flea_u8_t* shared_info, flea_al_u16_t shared_info_len, flea_u8_t* output, flea_al_u16_t output_len);

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
