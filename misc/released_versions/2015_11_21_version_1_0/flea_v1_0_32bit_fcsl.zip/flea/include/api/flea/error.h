/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#ifndef __flea_error_H_
#define __flea_error_H_

#ifdef __cplusplus
extern "C" {
#endif


typedef enum
{
  FLEA_ERR_FINE    =    0,
  FLEA_ERR_INT_ERR  =   0x0001,
  FLEA_ERR_INV_STATE =   0x0002,
  FLEA_ERR_FAILED_TEST =  0x0003,
  FLEA_ERR_INTEGRITY_FAILURE  = 0x0004,
  FLEA_ERR_INV_SIGNATURE  = 0x0005,
  FLEA_ERR_INV_ARG                 = 0x0006,
  FLEA_ERR_INV_ALGORITHM        = 0x0008,
  FLEA_ERR_INV_MAC             = 0x0009,
  FLEA_ERR_POINT_NOT_ON_CURVE  = 0x000A,
  FLEA_ERR_INV_ECC_DP          = 0x000B,
  FLEA_ERR_INV_KEY_SIZE        = 0x000C,
  FLEA_ERR_ZERO_POINT_AFF_TRF    = 0x0020,
  FLEA_ERR_BUFF_TOO_SMALL           = 0x00A0,
  FLEA_ERR_DECODING_FAILURE     = 0x00A1,
  FLEA_ERR_PRNG_NVM_WRITE_ERROR = 0x00B1,
  FLEA_ERR_RNG_NOT_SEEDED       = 0x00B2,
  FLEA_ERR_OUT_OF_MEM               = 0x00FF

} flea_err_t;

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
