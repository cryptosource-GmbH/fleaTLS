var group__mem__cfg =
[
    [ "FLEA_HEAP_MODE", "group__mem__cfg.html#ga35f1b139ece87c93439941cf268d93a9", null ]
];