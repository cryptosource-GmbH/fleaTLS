var hostn__ver_8h =
[
    [ "flea_host_id_type_e", "hostn__ver_8h.html#aef418b4f8580409cc8f5664fda9ea3bd", [
      [ "flea_host_ipaddr", "hostn__ver_8h.html#aef418b4f8580409cc8f5664fda9ea3bda82a3919bb8b0c626bdb5b258b8bfde80", null ],
      [ "flea_host_dnsname", "hostn__ver_8h.html#aef418b4f8580409cc8f5664fda9ea3bda352a0f529aec5781a66fb509579fbbe7", null ]
    ] ]
];