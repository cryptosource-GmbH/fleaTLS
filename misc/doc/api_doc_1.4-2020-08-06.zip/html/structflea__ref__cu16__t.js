var structflea__ref__cu16__t =
[
    [ "data__pcu16", "structflea__ref__cu16__t.html#ac45ccc2b4898567074e1554e037ea7f4", null ],
    [ "len__dtl", "structflea__ref__cu16__t.html#ae80bdbf9c11961bc376e1ceb387ad355", null ]
];