var group__dbg__cfg =
[
    [ "FLEA_DO_PRINTF_TEST_OUTPUT", "group__dbg__cfg.html#gaf541fb749d241a8ee9a0d0fada777696", null ],
    [ "FLEA_NO_DEV_ASSERTIONS", "group__dbg__cfg.html#ga2e34f60b04dbce2e57f420d310afe39f", null ]
];