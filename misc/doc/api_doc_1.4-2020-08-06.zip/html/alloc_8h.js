var alloc_8h =
[
    [ "__FLEA_FREE_BUF_SET_NULL", "alloc_8h.html#aa84b94c7faa8285ee3f8014f5e863f04", null ],
    [ "FLEA_ALLOC_MEM", "alloc_8h.html#ab81b08a79d196aeec647425ca17cbd4b", null ],
    [ "FLEA_ALLOC_MEM_ARR", "alloc_8h.html#a35f3a51d033f8187009fc7598d376737", null ],
    [ "FLEA_ALLOC_MEM_NOCHK", "alloc_8h.html#aaf74d692c21ade709e8c0baf4efd9206", null ],
    [ "FLEA_ALLOC_TYPE", "alloc_8h.html#a537ac7a5388c2cacb56f67ee0cfb40aa", null ],
    [ "FLEA_DECL_DYN_LEN", "alloc_8h.html#af543f7819aad2f93fe09f3ad56e1907c", null ],
    [ "FLEA_DO_IF_USE_HEAP_BUF", "alloc_8h.html#aaf3ba52d7ca08645695bfdec586f7f14", null ],
    [ "FLEA_FREE_BUF_SECRET_ARR", "alloc_8h.html#acd2ff6489ba093d42a97c40c54a552d7", null ],
    [ "FLEA_FREE_MEM", "alloc_8h.html#a805da8a615ac0172a52f1fb80c45af71", null ],
    [ "FLEA_FREE_MEM_CHECK_NULL_SECRET_ARR", "alloc_8h.html#a7e3a91f7a0d4432f3b84fcaab9f7073c", null ],
    [ "FLEA_FREE_MEM_CHECK_SET_NULL_SECRET_ARR", "alloc_8h.html#a77be42c4e72cf7c7306b45732cfae62a", null ],
    [ "FLEA_FREE_MEM_CHK_NULL", "alloc_8h.html#a87d8bf90d3b80fb4ba4503234276f7f9", null ],
    [ "FLEA_FREE_MEM_CHK_SET_NULL", "alloc_8h.html#abc1f58e65b55069dbc295b64012d5cec", null ],
    [ "FLEA_FREE_MEM_SET_NULL", "alloc_8h.html#a8245107f9706df968492681f3b086578", null ],
    [ "FLEA_FREE_MEM_SET_NULL_IF_USE_HEAP_BUF", "alloc_8h.html#a4f00714fbdd97037a6910dc3ae6c83e2", null ],
    [ "FLEA_HEAP_OR_STACK_CODE", "alloc_8h.html#ab34d80d9c1d361a2bf88f938a299e3ed", null ],
    [ "MY_FLEA_FREE_MEM", "alloc_8h.html#a6ce734689dc7759956a5a7401ed52326", null ],
    [ "THR_flea_alloc__ensure_buffer_capacity", "alloc_8h.html#abfda52087aa8e8d9a6653be8d6ba905e", null ],
    [ "THR_flea_alloc__realloc_mem", "alloc_8h.html#a09dd6f3d90d4c82c448af6036fa7277c", null ]
];