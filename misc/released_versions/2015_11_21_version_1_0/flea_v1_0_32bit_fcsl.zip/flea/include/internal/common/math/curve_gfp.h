/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#ifndef _flea_curve_gfp__H_
#define _flea_curve_gfp__H_

#include "internal/common/math/mpi.h"

typedef struct
{
  flea_mpi_t m_a;
  flea_mpi_t m_b;
  flea_mpi_t m_p;

} flea_curve_gfp_t;

flea_err_t THR_flea_curve_gfp_t__init(flea_curve_gfp_t* p_curve, const flea_u8_t* a_enc, flea_al_u16_t a_enc_len, const flea_u8_t* b_enc, flea_al_u16_t b_enc_len, const flea_u8_t* p_enc, flea_al_u16_t p_enc_len, flea_uword_t* memory, flea_al_u16_t memory_word_len);

flea_err_t THR_flea_curve_gfp_t__init_dp_array(flea_curve_gfp_t* p_curve, const flea_u8_t* enc_cp, flea_uword_t* memory, flea_al_u16_t memory_word_len);

#endif /* h-guard */
