/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



#ifndef __types_H_
#define __types_H_

#include "flea/error.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef unsigned char flea_u8_t;
typedef signed char flea_s8_t;
typedef unsigned short flea_u16_t;
typedef short flea_s16_t;
typedef unsigned int flea_u32_t;
typedef int flea_s32_t;
typedef unsigned long long flea_u64_t;
typedef long long flea_s64_t;

// "at least" width types
typedef flea_u32_t flea_al_u8_t;
typedef flea_s32_t flea_al_s8_t;
typedef flea_u32_t flea_al_u16_t;
typedef flea_s32_t flea_al_s16_t;

typedef flea_u16_t flea_hlf_uword_t;
typedef flea_s16_t flea_hlf_sword_t;
typedef flea_u32_t flea_uword_t;
typedef flea_s32_t flea_sword_t;
typedef flea_u64_t flea_dbl_uword_t;
typedef flea_s64_t flea_dbl_sword_t;

typedef flea_u32_t flea_cycles_t;

#define FLEA_LOG2_WORD_BIT_SIZE 5
#define FLEA_UWORD_MAX ((flea_uword_t)(-1))
#define FLEA_HLF_UWORD_MAX ((flea_hlf_uword_t)(-1))

typedef flea_al_u8_t flea_bool_t;

/**
 * byte lengths of mpis
 */
typedef flea_u16_t flea_mpi_ulen_t;
typedef flea_s16_t flea_mpi_slen_t;

/**
 * bit lengths of mpis
 */
typedef flea_u16_t flea_mpi_ubil_t;
typedef flea_s16_t flea_mpi_sbil_t;

/**
 * type indicating possible data lengths
 */
#ifdef FLEA_HAVE_DTL_32BIT
typedef flea_u32_t flea_dtl_t;
#else
typedef flea_al_u16_t flea_dtl_t;
#endif

#define FLEA_FALSE 0
#define FLEA_TRUE 1

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
