/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



#include "internal/common/default.h"
#include "flea/error_handling.h"
#include "flea/types.h"
#include "flea/error.h"
flea_err_t THR_flea_test_flea_types ()
{
  FLEA_THR_BEG_FUNC();
  if(sizeof(flea_u8_t) != 1)
  {
    FLEA_THROW("wrong size for type", FLEA_ERR_FAILED_TEST);
  }
  if(sizeof(flea_s8_t) != 1)
  {
    FLEA_THROW("wrong size for type", FLEA_ERR_FAILED_TEST);
  }
  if(sizeof(flea_u16_t) != 2)
  {
    FLEA_THROW("wrong size for type", FLEA_ERR_FAILED_TEST);
  }
  if(sizeof(flea_s16_t) != 2)
  {
    FLEA_THROW("wrong size for type", FLEA_ERR_FAILED_TEST);
  }
  if(sizeof(flea_u32_t) != 4)
  {
    FLEA_THROW("wrong size for type", FLEA_ERR_FAILED_TEST);
  }
  if(sizeof(flea_s32_t) != 4)
  {
    FLEA_THROW("wrong size for type", FLEA_ERR_FAILED_TEST);
  }
  FLEA_THR_FIN_SEC();
}
