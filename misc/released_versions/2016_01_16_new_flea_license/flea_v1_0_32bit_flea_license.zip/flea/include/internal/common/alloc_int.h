/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



#ifndef _flea_alloc_int__H_
#define _flea_alloc_int__H_

#ifndef FLEA_USE_BUF_DBG_CANARIES

#   define FLEA_NB_STACK_BUF_ENTRIES(__name) FLEA_NB_ARRAY_ENTRIES(__name)

#   define __FLEA_GET_ALLOCATED_BUF_NAME(__name)  __name

#   define FLEA_BUF_SET_CANANRIES(__name, __size)

#   define FLEA_BUF_CHK_DBG_CANARIES(__name)

#ifdef FLEA_USE_HEAP_BUF

#   define FLEA_DECL_BUF(__name, __type, __static_size) \
  __type * __name = NULL

#   define FLEA_ALLOC_BUF(__name, __dynamic_size) \
  FLEA_ALLOC_MEM_ARR(__name, __dynamic_size)

#   define FLEA_FREE_BUF_FINAL(__name) \
  FLEA_FREE_MEM_CHK_NULL(__name)

#   define FLEA_FREE_BUF(__name) \
  FLEA_FREE_MEM_CHK_SET_NULL(__name)

#   define FLEA_FREE_BUF_FINAL_SECRET_ARR(__name, __type_len) \
  do { \
    if(__name) { \
      flea_memzero_secure((flea_u8_t*)__name, (__type_len) * sizeof(__name[0])); \
      FLEA_FREE_MEM(__name); \
    } \
  } while(0)

#elif defined FLEA_USE_STACK_BUF // #ifdef FLEA_USE_HEAP_BUF

#   define FLEA_DECL_BUF(__name, __type, __static_size) \
  __type __name [__static_size]

#   define FLEA_STACK_BUF_NB_ENTRIES(__name) (sizeof(__name) / sizeof(__name[0]))

#   define FLEA_ALLOC_BUF(__name, __dynamic_size)

#   define FLEA_FREE_BUF_FINAL(__name)

#   define FLEA_FREE_BUF(__name)

#   define FLEA_FREE_BUF_FINAL_SECRET_ARR(__name, __type_len) \
  do { \
    flea_memzero_secure((flea_u8_t*)__name, (__type_len) * sizeof(__name[0])); \
  } while(0)
#else
#   error neither heap nor stack buf defined
#endif  // #ifdef FLEA_USE_HEAP_BUF

#endif  // #ifndef FLEA_USE_BUF_DBG_CANARIES

#endif  /* h-guard */

