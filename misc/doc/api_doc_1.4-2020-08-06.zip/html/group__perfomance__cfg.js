var group__perfomance__cfg =
[
    [ "FLEA_CRT_RSA_WINDOW_SIZE", "group__perfomance__cfg.html#gaa2ee748758c1f82a293be07797c2748e", null ],
    [ "FLEA_ECC_SINGLE_MUL_MAX_WINDOW_SIZE", "group__perfomance__cfg.html#gaad7a2e6ddd268692170a525a3cfd0159", null ],
    [ "FLEA_HAVE_AES_BLOCK_DECR", "group__perfomance__cfg.html#gadb3fba8fc84cc99d00ed6a03e7454b6e", null ],
    [ "FLEA_USE_MD5_LOOP_UNROLL", "group__perfomance__cfg.html#ga2aa844a401557e3340d5c46aa507b6eb", null ],
    [ "FLEA_USE_SHA1_LOOP_UNROLL", "group__perfomance__cfg.html#ga9528e071544b3cdd96a9b1cbaae487af", null ],
    [ "FLEA_USE_SHA256_LOOP_UNROLL", "group__perfomance__cfg.html#gaa3b5a2e6f72b3a651d80929457335593", null ],
    [ "FLEA_USE_SHA512_LOOP_UNROLL", "group__perfomance__cfg.html#gaf88e5bfb4165fb01b8b420d3f626011d", null ],
    [ "FLEA_USE_SMALL_AES", "group__perfomance__cfg.html#ga7f20f86e825a37124bb872f679a11722", null ]
];