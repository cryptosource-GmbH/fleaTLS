var structflea__cert__store__t =
[
    [ "enc_cert_refs__bcu8", "structflea__cert__store__t.html#abd3c0ab055ee8d9ae7953382179e0a6d", null ],
    [ "nb_alloc_certs__dtl", "structflea__cert__store__t.html#ad847c592c9db0aeb408b5da4de6fb03b", null ],
    [ "nb_set_certs__u16", "structflea__cert__store__t.html#a9e82689d8a04f61da635516fc67d78e6", null ]
];