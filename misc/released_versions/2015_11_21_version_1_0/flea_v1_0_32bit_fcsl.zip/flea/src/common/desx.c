/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#include "internal/common/default.h"
#include "internal/common/block_cipher/des.h"
#include "internal/common/block_cipher/desx.h"
#include "flea/alloc.h"
#include "flea/bin_utils.h"
#include "flea/error_handling.h"
#include "flea/block_cipher.h"

#define  FLEA_DES_BLOCK_SIZE 8

#if defined FLEA_HAVE_DES && defined FLEA_HAVE_DESX

flea_err_t THR_flea_desx_setup_key (flea_ecb_mode_ctx_t* ctx__pt,   const flea_u8_t *key)
{
  FLEA_THR_BEG_FUNC();

  FLEA_CCALL(THR_flea_single_des_setup_key(ctx__pt, key));
  memcpy(ctx__pt->expanded_key__bu8 + 32, key + 8, 2 * FLEA_DES_BLOCK_SIZE);
  FLEA_THR_FIN_SEC_empty();
}

void flea_desx_encrypt_block (const flea_ecb_mode_ctx_t* ctx__pt, const flea_u8_t* input__pcu8, flea_u8_t* output__pu8)
{
  flea__xor_bytes(output__pu8, ((const flea_u8_t*)(ctx__pt->expanded_key__bu8 + 32)), input__pcu8, FLEA_DES_BLOCK_SIZE);
  flea_single_des_encrypt_block(ctx__pt, output__pu8, output__pu8);
  flea__xor_bytes_in_place(output__pu8, ((const flea_u8_t*)(ctx__pt->expanded_key__bu8 + 32)) + FLEA_DES_BLOCK_SIZE, FLEA_DES_BLOCK_SIZE);
}

void flea_desx_decrypt_block (const flea_ecb_mode_ctx_t* ctx__pt, const flea_u8_t* input__pcu8, flea_u8_t* output__pu8)
{
  flea__xor_bytes(output__pu8, ((const flea_u8_t*)(ctx__pt->expanded_key__bu8 + 32)) + FLEA_DES_BLOCK_SIZE, input__pcu8, FLEA_DES_BLOCK_SIZE);
  flea_single_des_decrypt_block(ctx__pt, output__pu8, output__pu8);
  flea__xor_bytes_in_place(output__pu8, ((const flea_u8_t*)(ctx__pt->expanded_key__bu8 + 32)), FLEA_DES_BLOCK_SIZE);
}

#endif // #if defined FLEA_HAVE_DES && defined FLEA_HAVE_DESX
