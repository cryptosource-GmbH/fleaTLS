var group__arch__opt =
[
    [ "FLEA_HAVE_BE_ARCH_OPT", "group__arch__opt.html#ga62c2979b6da26be5934e74c153fa5611", null ],
    [ "FLEA_HAVE_DTL_32BIT", "group__arch__opt.html#ga72ee3d0442188e61834b90359530993b", null ]
];