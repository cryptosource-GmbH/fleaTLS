/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _flea_algo_config__H_
#define _flea_algo_config__H_

#include "internal/common/algo_len_int.h"


/**
 * Maximal size of the
 */
#define FLEA_RSA_CRT_KEY_INTERNAL_FORMAT_MAX_SIZE ((((FLEA_RSA_MAX_KEY_BIT_SIZE)+7) / 8) * 5)

/**
 * Maximal length of the ECDSA signature in simple concatenation format
 */
#define FLEA_ECDSA_MAX_SIG_LEN ((FLEA_ECC_MAX_MOD_BYTE_SIZE * 2))

/**
 * the maximal output length in bytes of the supported hash algorithms.
 */
#define FLEA_MAX_HASH_OUT_LEN __FLEA_COMPUTED_MAX_HASH_OUT_LEN

/**
 * Maximal size of an encoded public key.
 */
#define FLEA_PK_MAX_PUBKEY_LEN __FLEA_COMPUTED_MAX_PUBKEY_LEN

/**
 * Maximal length of a private key of a public key scheme
 */
#define FLEA_PK_MAX_PRIVKEY_LEN __FLEA_COMPUTED_PK_MAX_ASYM_PRIVKEY_LEN
/**
 * Maximal length of a signature of a public key scheme
 */
#define FLEA_PK_MAX_SIGNATURE_LEN __FLEA_COMPUTED_MAX_ASYM_SIG_LEN
/**
 * Maximal output length of a raw public key scheme function
 */
#define FLEA_PK_MAX_PRIMITIVE_INPUT_LEN __FLEA_COMPUTED_ASYM_PRIMITIVE_INPUT_LEN
/**
 * Maximal input length of a raw public key scheme function
 */
#define FLEA_PK_MAX_PRIMITIVE_OUTPUT_LEN __FLEA_COMPUTED_ASYM_MAX_PRIMITIVE_OUTPUT_LEN

#endif /* h-guard */
