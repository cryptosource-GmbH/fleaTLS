var structflea__byte__vec__t =
[
    [ "allo__dtl", "structflea__byte__vec__t.html#afa1df89eb30e4a46b9a0de4349df6a51", null ],
    [ "data__pu8", "structflea__byte__vec__t.html#a32472a26f600198679160db3a46faba8", null ],
    [ "len__dtl", "structflea__byte__vec__t.html#a6efe63e8bfaeee3a8488484dd00040ce", null ],
    [ "state__u8", "structflea__byte__vec__t.html#aacce77a25c2ab5e4f3f73aced7d9eea2", null ]
];