/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/


#ifndef _flea_ecdsa__H_
#define _flea_ecdsa__H_

#include "flea/types.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Verify an ECDSA signature on a hash value.
 *
 * @param enc_r big endian encoded value of the signature part r
 * @param enc_r_len length of encr_r
 * @param enc_s big endian encoded value of the signature part s
 * @param enc_s_len length of encr_r
 * @param message the hash value that was signed
 * @param message_len the length of message
 * @param dp pointer to the domain parameters in the flea internal format
 * associated with the key
 * @param pub_point_enc the encoded public point
 * @param pub_point_enc_len the length of pub_point_enc
 *
 * @return flea error code: FLEA_ERR_FINE on success verification, FLEA_ERR_INV_SIGNATURE if the signature is
 * invalid
 *
 */
flea_err_t THR_flea_ecdsa__raw_verify(const flea_u8_t* enc_r, flea_al_u8_t enc_r_len, const flea_u8_t* enc_s, flea_al_u8_t enc_s_len, const flea_u8_t* message, flea_al_u8_t message_len, const flea_u8_t * dp, const flea_u8_t* pub_point_enc,  flea_al_u8_t pub_point_enc_len);

/**
 * Generate an ECDSA signature on a hash value.
 *
 * @param result_r pointer to the memory area where to store the signature part r
 * @param result_r_len the length of result_r
 * @param result_r pointer to the memory area where to store the signature part s
 * @param result_s_len the length of result_s
 * @param message the hash value that to be signed signed
 * @param message_len the length of message
 * @param dp pointer to the domain parameters in the flea internal format
 * @param priv_key_enc the big endian encoded private key value
 * @param priv_key_enc_len the length of priv_key_enc
 *
 * @return flea error code
 */
flea_err_t THR_flea_ecdsa__raw_sign(flea_u8_t* result_r, flea_al_u8_t* result_r_len, flea_u8_t* result_s, flea_al_u8_t* result_s_len, const flea_u8_t* message, flea_al_u8_t message_len, const flea_u8_t* dp, const flea_u8_t* priv_key_enc, flea_al_u8_t priv_key_enc_len);

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
