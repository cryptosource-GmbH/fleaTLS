var structflea__x509__cert__ref__t =
[
    [ "cert_signature_as_bit_string__t", "structflea__x509__cert__ref__t.html#a347bb4458cc0799795a048bbef2f935e", null ],
    [ "extensions__t", "structflea__x509__cert__ref__t.html#a6b8bcd0d5dd39bff6ea5d7a3767b31af", null ],
    [ "issuer__t", "structflea__x509__cert__ref__t.html#a0852fd106e21cf29da34bdc8fda10dcf", null ],
    [ "issuer_unique_id_as_bitstr__t", "structflea__x509__cert__ref__t.html#a17c56362654f22cfce8162b55d59479e", null ],
    [ "not_after__t", "structflea__x509__cert__ref__t.html#a92ea5e93d9b537c1445925b8336d8c3a", null ],
    [ "not_before__t", "structflea__x509__cert__ref__t.html#a81f585b551517703f21434392356d939", null ],
    [ "serial_number__t", "structflea__x509__cert__ref__t.html#a9bfa1a947d4e993cba17c9f0424f31b6", null ],
    [ "subject__t", "structflea__x509__cert__ref__t.html#a2e2dc7e72460467020087667180fc6a5", null ],
    [ "subject_public_key_info__t", "structflea__x509__cert__ref__t.html#abbbb4542e3c4e9dd099ec0cd34e72afe", null ],
    [ "subject_unique_id_as_bitstr__t", "structflea__x509__cert__ref__t.html#ab5dc94bda7f65b77d9d464af5a570944", null ],
    [ "tbs_sig_algid__t", "structflea__x509__cert__ref__t.html#af24645a53ef78372cdaf204324766951", null ],
    [ "version__u8", "structflea__x509__cert__ref__t.html#ab3a60423fa1c5900fcf880dc29490858", null ]
];