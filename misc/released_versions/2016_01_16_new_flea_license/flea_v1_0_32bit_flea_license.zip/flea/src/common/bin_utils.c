/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "internal/common/default.h"
#include "flea/bin_utils.h"
#include "flea/types.h"

void flea__xor_bytes_in_place (flea_u8_t* in_out, const flea_u8_t* in2, flea_dtl_t len)
{
  flea_dtl_t i;

  for(i = 0; i < len; i++)
  {
    in_out[i] ^= in2[i];
  }
}

void flea__xor_bytes (flea_u8_t* out, const flea_u8_t* in1, const flea_u8_t* in2, flea_dtl_t len__dtl)
{
  flea_dtl_t i;

  for(i = 0; i < len__dtl; i++)
  {
    out[i] = in1[i] ^ in2[i];
  }
}

void flea__encode_U32_LE (flea_u32_t to_enc, flea_u8_t res[4])
{
  res[3] = to_enc >> 24;
  res[2] = to_enc >> 16;
  res[1] = to_enc >> 8;
  res[0] = to_enc & 0xFF;
}

void flea__encode_U32_BE (flea_u32_t to_enc, flea_u8_t res[4])
{
  res[0] = to_enc >> 24;
  res[1] = to_enc >> 16;
  res[2] = to_enc >> 8;
  res[3] = to_enc & 0xFF;
}

flea_u32_t flea__decode_U32_BE (const flea_u8_t enc[4])
{
  return ((flea_u32_t)enc[0] << 24) |
         ((flea_u32_t)enc[1] << 16) |
         ((flea_u32_t)enc[2] << 8 ) |
         ((flea_u32_t)(enc[3] & 0xFF));

}

void flea__increment_encoded_BE_int (flea_u8_t* ctr_block_pu8, flea_al_u8_t ctr_block_length_al_u8)
{
  flea_al_s8_t i;

  for(i = ctr_block_length_al_u8 - 1; i >= 0; i--)
  {
    flea_u8_t old_u8 = ctr_block_pu8[i];
    ctr_block_pu8[i] += 1;
    if(ctr_block_pu8[i] > old_u8)
    {
      // no overflow
      break;
    }
  }
}

flea_al_u8_t flea__nlz_uword (flea_uword_t x)
{
  flea_al_u8_t n = sizeof(flea_uword_t) * 8;  // i.e. 32 for 32-bit
  flea_al_u8_t c = sizeof(flea_uword_t) * 4;  // i.e. 16 for 32-bit

  do
  {
    flea_uword_t y;
    y = x >> c;
    if( y != 0)
    {
      n = n - c;
      x = y;
    }
    c = c >> 1;
  }
  while(c != 0);
  return n - x;
}

flea_mpi_ulen_t flea__get_BE_int_bit_len (const flea_u8_t* enc__pcu8, flea_mpi_ulen_t int_len__mpl)
{
  flea_mpi_ulen_t i;

  for(i = 0; i < int_len__mpl; i++)
  {
    if(enc__pcu8[i])
    {
      flea_al_s8_t j;
      for(j = 7; j >= 0; j--)
      {
        if(enc__pcu8[i] & (1 << j))
        {
          return j + 1 + (int_len__mpl - 1 - i) * 8;
        }
      }
    }
  }
  return 0;
}
