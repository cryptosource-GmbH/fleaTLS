/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _flea_mac_int__H_
#define _flea_mac_int__H_

#include "internal/common/default.h"
#include "flea/mac_fwd.h"

typedef enum { flea_cmac, flea_hmac } flea_mac_mode_id_t;

typedef struct
{
  flea_hash_ctx_t hash_ctx__t;
  flea_u8_t hash_output_len__u8;
  flea_u8_t key_byte_len__u8;
#ifdef FLEA_USE_HEAP_BUF
  flea_u8_t* key__bu8;
#else
  flea_u8_t key__bu8[__FLEA_COMPUTED_MAC_MAX_KEY_LEN];
#endif

} flea_mac_ctx_hmac_specific_t;

typedef struct
{
  flea_u8_t pending__u8;
  flea_ecb_mode_ctx_t cipher_ctx__t;

#ifdef FLEA_USE_HEAP_BUF
  flea_u8_t* prev_ct__bu8;
#else
  flea_u8_t prev_ct__bu8[FLEA_BLOCK_CIPHER_MAX_BLOCK_LENGTH];
#endif

} flea_mac_ctx_cmac_specific_t;


struct mac_config_entry_struct;
typedef struct mac_config_entry_struct mac_config_entry_t;

void flea_mac_ctx_t__dtor_cipher_ctx_ref(flea_mac_ctx_t* ctx__pt);

void flea_mac_ctx_t__reset_cmac(flea_mac_ctx_t* ctx__pt);

flea_err_t THR_flea_mac_ctx_t__ctor_cmac(flea_mac_ctx_t* ctx, const mac_config_entry_t* config_entry, const flea_u8_t* key, flea_al_u16_t key_len, flea_ecb_mode_ctx_t* ciph_ctx_ref);

#endif /* h-guard */
