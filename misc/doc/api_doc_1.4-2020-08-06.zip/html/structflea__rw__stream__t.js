var structflea__rw__stream__t =
[
    [ "close_func__f", "structflea__rw__stream__t.html#afe40eef2506d09d3666aba8ea3528803", null ],
    [ "custom_obj__pv", "structflea__rw__stream__t.html#a7a17432153b530296d39f793c0c3c384", null ],
    [ "flush_write_func__f", "structflea__rw__stream__t.html#adf871ab36e2b17e43776196094d3ef39", null ],
    [ "have_read_limit__b", "structflea__rw__stream__t.html#a534fcd19597dcf897636f4b9770528df", null ],
    [ "open_func__f", "structflea__rw__stream__t.html#afd9e446543597ff99b8b9a392a6bbeac", null ],
    [ "read_func__f", "structflea__rw__stream__t.html#a6dd75a3fa249cf538dd8b5197d451e3a", null ],
    [ "read_rem_len__u32", "structflea__rw__stream__t.html#ad4f4a16db39d1ae3f6428805cd74e82f", null ],
    [ "strm_type__e", "structflea__rw__stream__t.html#a82440a7f92c8aa7a3de084a8e5c24915", null ],
    [ "write_func__f", "structflea__rw__stream__t.html#af10e4eb70d7855d8c116b3dac3c6dc23", null ]
];