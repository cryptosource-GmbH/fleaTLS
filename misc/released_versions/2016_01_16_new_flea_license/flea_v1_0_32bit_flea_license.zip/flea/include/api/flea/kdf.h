/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _flea_kdf__H_
#define _flea_kdf__H_

#include "flea/hash.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Peform the ANSI X9.63 key derivation function.
 *
 * @param hash_id id of the hash algorithm to use in the key derivation function
 * @param input pointer to the input data
 * @param input_len length of input
 * @param shared_info shared info value to be used in the key derivation
 * function, may be NULL, then also its length must be 0
 * @param shared_info_len the length of shared_info
 * @param output pointer to the memory area where to store the computation
 * result
 * @param output_len the caller must provide a pointer to a value which contains
 * the available length of output. when the function returns, *output_len will
 * contain the length of the data set in output
 *
 * @return flea error code
 */
flea_err_t THR_flea_kdf_X9_63(flea_hash_id_t id, const flea_u8_t* input, flea_al_u16_t input_len, const flea_u8_t* shared_info, flea_al_u16_t shared_info_len, flea_u8_t* output, flea_al_u16_t output_len);

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
