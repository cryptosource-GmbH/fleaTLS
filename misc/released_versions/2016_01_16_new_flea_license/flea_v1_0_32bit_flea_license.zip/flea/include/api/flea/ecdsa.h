/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _flea_ecdsa__H_
#define _flea_ecdsa__H_

#include "flea/types.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Verify an ECDSA signature on a hash value.
 *
 * @param enc_r big endian encoded value of the signature part r
 * @param enc_r_len length of encr_r
 * @param enc_s big endian encoded value of the signature part s
 * @param enc_s_len length of encr_r
 * @param message the hash value that was signed
 * @param message_len the length of message
 * @param dp pointer to the domain parameters in the flea internal format
 * associated with the key
 * @param pub_point_enc the encoded public point
 * @param pub_point_enc_len the length of pub_point_enc
 *
 * @return flea error code: FLEA_ERR_FINE on success verification, FLEA_ERR_INV_SIGNATURE if the signature is
 * invalid
 *
 */
flea_err_t THR_flea_ecdsa__raw_verify(const flea_u8_t* enc_r, flea_al_u8_t enc_r_len, const flea_u8_t* enc_s, flea_al_u8_t enc_s_len, const flea_u8_t* message, flea_al_u8_t message_len, const flea_u8_t * dp, const flea_u8_t* pub_point_enc,  flea_al_u8_t pub_point_enc_len);

/**
 * Generate an ECDSA signature on a hash value.
 *
 * @param result_r pointer to the memory area where to store the signature part r
 * @param result_r_len the length of result_r
 * @param result_r pointer to the memory area where to store the signature part s
 * @param result_s_len the length of result_s
 * @param message the hash value that to be signed signed
 * @param message_len the length of message
 * @param dp pointer to the domain parameters in the flea internal format
 * @param priv_key_enc the big endian encoded private key value
 * @param priv_key_enc_len the length of priv_key_enc
 *
 * @return flea error code
 */
flea_err_t THR_flea_ecdsa__raw_sign(flea_u8_t* result_r, flea_al_u8_t* result_r_len, flea_u8_t* result_s, flea_al_u8_t* result_s_len, const flea_u8_t* message, flea_al_u8_t message_len, const flea_u8_t* dp, const flea_u8_t* priv_key_enc, flea_al_u8_t priv_key_enc_len);

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
