var structflea__privkey__t =
[
    [ "ec_priv_key_val__t", "structflea__privkey__t.html#aac089026342778d17782c2164730151f", null ],
    [ "key_bit_size__u16", "structflea__privkey__t.html#ada3b641f1b9655156babec4a6b81e799", null ],
    [ "key_type__t", "structflea__privkey__t.html#abbafe9c091607afcf59366f04936c6b8", null ],
    [ "max_primitive_input_len__u16", "structflea__privkey__t.html#afbb96651bef5f228e28829547b6cc7f3", null ],
    [ "privkey_with_params__u", "structflea__privkey__t.html#a6fdd74e772e44853b3a9f09f336e0abc", null ],
    [ "rsa_priv_key_val__t", "structflea__privkey__t.html#af55df983cefc238c3cc76a255b2fc88b", null ]
];