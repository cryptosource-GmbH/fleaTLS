/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef __flea_error_H_
#define __flea_error_H_

#ifdef __cplusplus
extern "C" {
#endif


typedef enum
{
  FLEA_ERR_FINE    =    0,
  FLEA_ERR_INT_ERR  =   0x0001,
  FLEA_ERR_INV_STATE =   0x0002,
  FLEA_ERR_FAILED_TEST =  0x0003,
  FLEA_ERR_INTEGRITY_FAILURE  = 0x0004,
  FLEA_ERR_INV_SIGNATURE  = 0x0005,
  FLEA_ERR_INV_ARG                 = 0x0006,
  FLEA_ERR_INV_ALGORITHM        = 0x0008,
  FLEA_ERR_INV_MAC             = 0x0009,
  FLEA_ERR_POINT_NOT_ON_CURVE  = 0x000A,
  FLEA_ERR_INV_ECC_DP          = 0x000B,
  FLEA_ERR_INV_KEY_SIZE        = 0x000C,
  FLEA_ERR_ZERO_POINT_AFF_TRF    = 0x0020,
  FLEA_ERR_BUFF_TOO_SMALL           = 0x00A0,
  FLEA_ERR_DECODING_FAILURE     = 0x00A1,
  FLEA_ERR_PRNG_NVM_WRITE_ERROR = 0x00B1,
  FLEA_ERR_RNG_NOT_SEEDED       = 0x00B2,
  FLEA_ERR_OUT_OF_MEM               = 0x00FF

} flea_err_t;

#ifdef __cplusplus
}
#endif

#endif /* h-guard */
