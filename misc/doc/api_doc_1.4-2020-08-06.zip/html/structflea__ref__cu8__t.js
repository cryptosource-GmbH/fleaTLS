var structflea__ref__cu8__t =
[
    [ "data__pcu8", "structflea__ref__cu8__t.html#add4d81d5037a23edb003f30d04242877", null ],
    [ "len__dtl", "structflea__ref__cu8__t.html#a3216c9f47d8712a54d941beca7f44faa", null ]
];