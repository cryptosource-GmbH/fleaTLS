/*
__________________
***** cryptosource
******************
  Cryptography. Security.

flea cryptographic library for embedded systems
Copyright (C) 2015-2016 cryptosource GmbH


flea license version 1.0

The source code may be used freely, provided that the following conditions are
met:

    1. Redistribution of the source code, including the header files, is not allowed. 

    2. Redistribution of binary code is allowed.

    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software 
       without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "flea/types.h"

// computes ~crc16
// initial remainder shall be zero for CCIT compatibility
flea_u16_t flea_crc16_ccit_compute (flea_u16_t crc_init__u16, const flea_u8_t* data__pcu8, flea_dtl_t data_len__dtl)
{
  flea_dtl_t i;

  for(i = 0; i < data_len__dtl; i++)
  {
    flea_al_s8_t j;
    flea_u8_t byte = data__pcu8[i];

    crc_init__u16 ^= (byte << 8);
    for(j = 0; j < 8; j++)
    {
      flea_u16_t mask__u16 = -(((crc_init__u16 ) & (1 << 15)) >> 15);
      crc_init__u16 = (crc_init__u16 << 1) ^ (0x1021 & mask__u16);
      byte <<= 1;
    }
  }
  return crc_init__u16;
}
