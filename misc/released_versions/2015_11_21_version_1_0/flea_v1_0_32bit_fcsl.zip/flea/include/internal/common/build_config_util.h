/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/



#ifndef _flea_build_config_util__H_
#define _flea_build_config_util__H_


#if defined FLEA_HAVE_ECDSA || defined FLEA_HAVE_ECKA
#define FLEA_HAVE_ECC
#endif

#ifdef FLEA_HAVE_RSA
#define FLEA_HAVE_PK_CS
#endif

#if defined FLEA_HAVE_RSA || defined FLEA_HAVE_ECDSA
#define FLEA_HAVE_ASYM_SIG
#endif

#ifndef FLEA_USE_HEAP_BUF
#define FLEA_USE_STACK_BUF
#endif

#ifdef FLEA_HAVE_AES_BLOCK_DECR
#define FLEA_DO_IF_HAVE_AES_BLOCK_DECR(x) x
#else
#define FLEA_DO_IF_HAVE_AES_BLOCK_DECR(x)
#endif

#if FLEA_CRT_RSA_WINDOW_SIZE > 1
#define FLEA_DO_IF_RSA_CRT_WINDOW_SIZE_GREATER_ONE(x) do { x } while(0)
#else
#define FLEA_DO_IF_RSA_CRT_WINDOW_SIZE_GREATER_ONE(x)
#endif

// fixed 32 bit difference so far
#define FLEA_RSA_CRT_PQ_BIT_DIFF 32
/************ Begin MAC and AE ************/

#ifdef FLEA_HAVE_EAX
#define FLEA_HAVE_AE
#define FLEA_HAVE_CMAC
#endif

#if defined FLEA_HAVE_HMAC || defined FLEA_HAVE_CMAC
#define FLEA_HAVE_MAC
#endif

/************ End MAC and AE ************/


#endif /* h-guard */
