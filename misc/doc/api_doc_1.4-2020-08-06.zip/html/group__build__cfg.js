var group__build__cfg =
[
    [ "Debugging configuration", "group__dbg__cfg.html", "group__dbg__cfg" ],
    [ "Memory configuration", "group__mem__cfg.html", "group__mem__cfg" ],
    [ "Platform support", "group__pltf__support.html", "group__pltf__support" ],
    [ "Algorithm support configuration", "group__algo__support__cfg.html", "group__algo__support__cfg" ],
    [ "Algorithm key and parameter sizes", "group__crypto__params.html", "group__crypto__params" ],
    [ "Performance optimization options", "group__perfomance__cfg.html", "group__perfomance__cfg" ],
    [ "Side-Channel Countermeasures", "group__sccm__cfg.html", "group__sccm__cfg" ],
    [ "Configuration of reserved memory spaces", "group__space__reserv.html", "group__space__reserv" ],
    [ "TLS configuration", "group__tls__cfg.html", "group__tls__cfg" ],
    [ "Architectural optimizations", "group__arch__opt.html", "group__arch__opt" ],
    [ "Multithreading support", "group__mt__cfg.html", "group__mt__cfg" ]
];