var group__space__reserv =
[
    [ "FLEA_CERT_AND_CRL_PREALLOC_OBJ_CNT", "group__space__reserv.html#ga8b4f586bef9802a8869e28df42121285", null ],
    [ "FLEA_CERT_STORE_PREALLOC", "group__space__reserv.html#gaeda60c879e2f15ca322c65c5d1ee668f", null ],
    [ "FLEA_HAVE_X509_DN_DETAILS", "group__space__reserv.html#ga63c146265844820827bab95f173a3018", null ],
    [ "FLEA_MAX_CERT_CHAIN_DEPTH", "group__space__reserv.html#gacb2049d028ba8e658f487658dd72d3f3", null ],
    [ "FLEA_MAX_CERT_COLLECTION_NB_CRLS", "group__space__reserv.html#gacb5db653cebd8852d6f9398f5257c9b9", null ],
    [ "FLEA_MAX_CERT_COLLECTION_SIZE", "group__space__reserv.html#ga724e95504074139d81f542e010d9bbe4", null ],
    [ "FLEA_STKMD_X509_MAX_CERT_SIZE", "group__space__reserv.html#gac112c5ff43965da4a672e1bd8b219042", null ],
    [ "FLEA_STKMD_X509_MAX_CRLDP_LEN", "group__space__reserv.html#gae9dadc46b50a138e7a4d932be4ccecd1", null ],
    [ "FLEA_STKMD_X509_MAX_ISSUER_DN_RAW_BYTE_LEN", "group__space__reserv.html#gac0c04638581e4966eb059b2c5c7f7ff9", null ],
    [ "FLEA_STKMD_X509_SAN_ELEMENT_MAX_LEN", "group__space__reserv.html#ga58ceb7f55995c6daed04dc34cd91c264", null ],
    [ "FLEA_X509_CERT_REF_WITH_DETAILS", "group__space__reserv.html#gad68daba0166f8ab98e6679b8fe94cfca", null ],
    [ "FLEA_X509_NAME_COMPONENT_MAX_BYTE_LEN", "group__space__reserv.html#ga4348f5533a8d73f1af0dbe1610727a52", null ]
];