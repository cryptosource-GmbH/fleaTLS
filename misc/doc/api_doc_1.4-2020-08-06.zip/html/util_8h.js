var util_8h =
[
    [ "flea_ref_cu8_t", "structflea__ref__cu8__t.html", "structflea__ref__cu8__t" ],
    [ "flea_ref_cu16_t", "structflea__ref__cu16__t.html", "structflea__ref__cu16__t" ],
    [ "FLEA_ASSGN_REF_FROM_BYTE_VEC", "util_8h.html#a1f6fbe2369b4a9f9533b280a96b50984", null ],
    [ "FLEA_COMMA", "util_8h.html#a8f7a4f39310971cf3e51e411ae901030", null ],
    [ "FLEA_MEMSET", "util_8h.html#ab9637b0a7796f7acb29a4e675ff857dd", null ],
    [ "FLEA_SWAP", "util_8h.html#a3f203a6585aa874d37eab200f8ea6efb", null ],
    [ "FLEA_SWAP_TYPE", "util_8h.html#aa34be025a9d93e8a64b9ffa4eb28e2d6", null ],
    [ "FLEA_ZERO_STRUCT", "util_8h.html#aeb74a55f9a477b5728d102ba14d105a0", null ],
    [ "flea_copy_rcu8_use_mem", "util_8h.html#a2e622cb08e77630e051c37ba89f49c86", null ],
    [ "flea_memcmp_wsize", "util_8h.html#a574cecd9fe249690077c646959095672", null ],
    [ "flea_memzero_secure", "util_8h.html#a2dba21f6daef38ba756f878aa5c47f2d", null ],
    [ "flea_rcu8_cmp", "util_8h.html#a3e4c93585174d3dbcedd07f197a011a6", null ],
    [ "flea_sec_mem_equal", "util_8h.html#a7c6b84e0d318fbb000185fb2f0f15cdc", null ],
    [ "flea_swap_mem", "util_8h.html#a603ddc58c165bacb984be29a08bb787b", null ],
    [ "flea_waste_cycles", "util_8h.html#aa7448cde65d9a56e3d42e588420f26a6", null ],
    [ "THR_flea_add_dtl_with_overflow_check", "util_8h.html#a9747a85bd051eab8fe5c4cb79c3b7508", null ]
];