/*
__________________
***** cryptosource
******************
    flea cryptographic library for embedded systems
    Copyright (C) 2015 cryptosource GmbH

    This program, a variant of the flea cryptographic library, is released under the flea closed
    source license version 1.0, which you have received with the program.

    This program is provided as-is, WITHOUT ANY WARRANTY; 
    without even the implied warranty of MERCHANTABILITY 
    or fitness for a particular purpose. In no event shall cryptosource GmbH or
    any other contributor be liable for any
    direct, indirect, incidental, special, exemplary, or consequential damages
    (including, but not limited to, procurement of substitute goods or services;
    loss of use, data, or profits; or business interruption) however caused and
    on any theory of liability, whether in contract, strict liability, or tort
    (including negligence or otherwise) arising in any way out of the use of this
    software, even if advised of the possibility of such damage.
*/




#include "internal/common/default.h"
#include "internal/common/hash/davies_meyer_hash.h"
#include "flea/hash.h"
#include "flea/error_handling.h"
#include "flea/error.h"
#include "internal/common/block_cipher/aes.h"
#include "flea/alloc.h"
#include "flea/bin_utils.h"
#include <string.h>

#ifdef FLEA_HAVE_DAVIES_MEYER_HASH
void flea_hash_davies_meyer_aes128_init (flea_hash_ctx_t* ctx__pt)
{
  memset(ctx__pt->hash_state, 0, 16);
}
flea_err_t THR_flea_hash_davies_meyer_aes128_compression (flea_hash_ctx_t* ctx__pt, const flea_u8_t* input)
{
  FLEA_DECL_OBJ(aes_ctx, flea_ecb_mode_ctx_t);
  FLEA_DECL_BUF(tmp_state, flea_u8_t, FLEA_AES_BLOCK_LENGTH);
  FLEA_THR_BEG_FUNC();


  FLEA_ALLOC_BUF(tmp_state, FLEA_AES_BLOCK_LENGTH);

  FLEA_CCALL(THR_flea_ecb_mode_ctx_t__ctor(&aes_ctx, flea_aes128, input, FLEA_AES128_KEY_BYTE_LENGTH, flea_encrypt));

  flea_aes_encrypt_block(&aes_ctx, (flea_u8_t*)ctx__pt->hash_state, tmp_state);

  flea__xor_bytes_in_place((flea_u8_t*)ctx__pt->hash_state, tmp_state, FLEA_AES_BLOCK_LENGTH);

  FLEA_THR_FIN_SEC(
    FLEA_FREE_BUF_FINAL(tmp_state);
    flea_ecb_mode_ctx_t__dtor(&aes_ctx);
    );
}
#endif // #ifdef FLEA_HAVE_DAVIES_MEYER_HASH
