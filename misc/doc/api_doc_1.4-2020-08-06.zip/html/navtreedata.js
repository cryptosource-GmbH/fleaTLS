var NAVTREE =
[
  [ "fleaTLS", "index.html", [
    [ "fleaTLS Manual", "index.html", "index" ],
    [ "Modules", "modules.html", "modules" ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"ae_8h.html",
"ec__key__gen_8h.html",
"group__algo__support__cfg.html#ga1969c8cc9b986ff4492eca32aab9e130",
"lib_8h.html#aaf08ef94ba4dae736836ebc6cd07f83d",
"structflea__gmt__time__t.html#a5c9549a7bbfece6b86bc7d02eff019cf",
"x509_8h.html#a5199f52591c11b7689fca438ecde1f70ae29059b7df5330ef8be532bb14673d59"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';