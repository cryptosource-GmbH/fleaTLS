var group__crypto__params =
[
    [ "FLEA_ECC_MAX_COFACTOR_BIT_SIZE", "group__crypto__params.html#gacf8e3b8b49510ac34d41b2667ee97d2a", null ],
    [ "FLEA_ECC_MAX_MOD_BIT_SIZE", "group__crypto__params.html#ga305e5c82c58f457091f44898f0f23b09", null ],
    [ "FLEA_RSA_MAX_KEY_BIT_SIZE", "group__crypto__params.html#gacd29beeed27ce8e221db103c88df5d2c", null ],
    [ "FLEA_RSA_MAX_PUB_EXP_BIT_LEN", "group__crypto__params.html#ga5eba25d29604cf43e3ce31b499263541", null ]
];