var ecc_8h =
[
    [ "FLEA_ECC_MAX_PRIVATE_KEY_BYTE_SIZE", "ecc_8h.html#a87b5722b8b462e447d5141d37a363eeb", null ],
    [ "FLEA_ECC_MAX_UNCOMPR_POINT_SIZE", "ecc_8h.html#aa203262082bba438c39a151be2a6071e", null ]
];